<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks', 'wp-i18n', 'wp-polyfill'), 'version' => '919a81c214a16696c125');
